import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: '<h2>Hello</h2>'
 })
export class HelloComponent {}
