import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CourseListComponent} from './course/courselist.component';
import {CreateCourseComponent} from './course/createcourse.component';
import {CourseDetailComponent} from './course/coursedetail.component';
import {Error404Component} from './error/error404.component';
import {CourseRouterActivatorService} from './shared/courseid.router.activate'
import {UserProfileComponent} from './user/user.profile.component'
import {UserModule} from './user/user.module'

const routes: Routes = [
  {path:'courses', component : CourseListComponent},
  {path:'courses/new', component : CreateCourseComponent,
        canDeactivate:['canDeacivateCreateCourse']},
  {path:'courses/:a', component : CourseDetailComponent,
   canActivate : [CourseRouterActivatorService] },
  {path:'404', component : Error404Component},
  {path:'', redirectTo:'/courses',pathMatch : 'full'},
  {path:'user', loadChildren:'./user/user.module#UserModule'},
  {path:'**', redirectTo:'/404',pathMatch : 'full'}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
