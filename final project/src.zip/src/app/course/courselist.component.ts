import { Component } from '@angular/core';
import {CourseService} from '../shared/course.service';
import {Course} from '../shared/Course.model'
@Component({
  selector: 'course-list',
  template: `<div>
  <h1>Upcoming Courses</h1>
<hr/>
<div class= "row">
<div *ngFor="let course of courses"  class="col-md-5"> 
<course-thumbnail  [tempCourse]= 'course' (outputCourse)='handleInParent($event)' ></course-thumbnail>
</div>
</div>
`
})
export class CourseListComponent {
  courses : Course[];
  constructor(private courseService : CourseService){
     courseService.getAllCourses().
     subscribe((data) => this.courses = data);
  }

  parentFunction(data) {
    console.log('Parent :' + data);
  }


}
