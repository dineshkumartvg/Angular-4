import { Component,Input,Output,EventEmitter } from '@angular/core';
import {Course} from '../shared/Course.model'
@Component({
  selector: 'course-thumbnail',
  template: `<div  class="well hoverwell thumbnail" [routerLink]="['/courses',tempCourse?.id]">
<h2>
 Name : {{tempCourse?.name | uppercase}}
 </h2>
<div>Date : {{tempCourse?.date | date}} </div>
<div>Time : {{tempCourse?.time}} </div>
<div>Price : {{tempCourse?.price | currency:'INR'}} </div>
<div>Duration : {{tempCourse?.duration | duration }} </div>
<div *ngIf="tempCourse?.location">
Location :<span>{{tempCourse?.location?.trainingRoom}},</span>
<span class="pad-left">{{tempCourse?.location?.building}},{{tempCourse.location?.city}}</span>
</div>
<div *ngIf="tempCourse?.onlineUrl">Online Url : {{tempCourse?.onlineUrl}}</div>
<button class="btn btn-primary" (click) = "transferthedatatoParent()">Enroll</button>
</div>
`,
styles:[`
        .pad-left{margin-left: 10px;}
        .well div {color: #bbb;}`
        ]
 })
export class CourseThumbnailComponent {
  @Input() tempCourse : Course;
  @Output() eventcaptured =  new EventEmitter();
  foo  = 'Hello world';
  transferthedatatoParent(){
    this.eventcaptured.emit(this.tempCourse.name);
  }

  callMe(){
    console.log('Call Me function invoked');
  }
}

