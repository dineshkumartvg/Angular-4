import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {CourseService} from '../shared/course.service'

@Component({
  templateUrl: './create.course.component.html',
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class CreateCourseComponent {
    isDirty : boolean = true;
  constructor(private router : Router,private courseService : CourseService){}
  
  saveCourse(newCourse){
    this.courseService.saveCourse(newCourse)
    this.isDirty  = false;
    this.router.navigate(['/courses'])
  }
  cancel(){
    this.router.navigate(['/courses']);
  }
}