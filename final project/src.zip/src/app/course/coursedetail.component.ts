import { Component,OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {CourseService} from '../shared/course.service';
import {Course} from '../shared/Course.model'
@Component({
   templateUrl: './coursedetail.component.html'
})
export class CourseDetailComponent implements OnInit {
  course : Course;
  constructor(private courseService : CourseService,
              private activatedRoute : ActivatedRoute){    
  }

  ngOnInit(){
    this.course =  this.courseService.getCourseById(+this.activatedRoute.snapshot.params['a']);
  }
}
