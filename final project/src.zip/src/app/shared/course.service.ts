import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Course} from './Course.model'
import { Observable } from 'rxjs';

@Injectable()
export class CourseService {
 private _url = "http://172.23.92.44:9191/courses"
  constructor(private http : HttpClient){
  }

  getAllCourses() : Observable<Course[]> {
      return this.http.get<Course[]>(this._url);
   }

    getCourseById(id : number){
        return courses.find(course => course.id === id)
    }

    saveCourse(newCourse){
      newCourse.id = 999
      courses.push(newCourse)
    }
  
}
const courses : Course[]  = [
    {
      id: 1,
      name: 'Angular Connect',
      date: new Date('9/26/2036'),
      time: '10:00 am',
      duration : 1,
      price: 1000,
      imageUrl: '/assets/images/angularconnect-shield.png',
      location: {
        trainingRoom: 'Harvard',
        building: 'Campus',
        city: 'Hyd'
      }
    },
    {
      id: 2,
      name: 'ng-nl',
      date: new Date('4/15/2037'),
      time: '9:00 am',
      price: 950.00,
      imageUrl: '/assets/images/ng-nl.png',
      onlineUrl : 'http://www.qwertasasa.com'
    },
    {
      id: 3,
      name: 'ng-conf 2037',
      date: new Date('5/4/2037'),
      time: '9:00 am',
      price: 759.00,
      imageUrl: '/assets/images/ng-conf.png',
      location: {
        trainingRoom: 'C.V Raman',
        city: 'Hyderabad',
        building: 'Campus'
      }
    },
    {
      id: 4,
      name: 'UN Angular Summit',
      date: new Date('6/10/2037'),
      time: '8:00 am',
      price: 800.00,
      imageUrl: '/assets/images/basic-shield.png',
      location: {
        trainingRoom: 'Gelilio',
        city: 'Hyderbad',
        building: 'Campus'
      }
    },
    {
      id: 5,
      name: 'ng-vegas',
      date: new Date('2/10/2037'),
      time: '9:00 am',
      price: 400.00,
      imageUrl: '/assets/images/ng-vegas.png',
      location: {
        trainingRoom: 'Harvard',
        city: 'Hyderabad',
        building: 'Campus'
      },
    }
  ];