import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CourseListComponent, 
         CourseThumbnailComponent,
         CourseDetailComponent,
         CreateCourseComponent,
         DurationPipe} from './index';

import {NavBarComponent } from './navigation/navbar.component';
import {CourseService} from './shared/course.service';
import {Error404Component} from './error/error404.component';
import {CourseRouterActivatorService} from './shared/courseid.router.activate';
import {UserAuthenticateService} from './user/user.authenticate.service'
@NgModule({
  declarations: [
    AppComponent,
    CourseListComponent,
    CourseThumbnailComponent,
    NavBarComponent,
    CourseDetailComponent,
    Error404Component,
    CreateCourseComponent,
    DurationPipe
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers : [CourseService, 
               CourseRouterActivatorService,
               {provide:'canDeacivateCreateCourse',useValue:checkDirtyState},
               UserAuthenticateService
              ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function checkDirtyState(createCourse : CreateCourseComponent){
  if(createCourse.isDirty)
    return  window.confirm('You want the page with out saving the data?')
	return true
 }