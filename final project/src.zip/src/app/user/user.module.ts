import {  CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {UserProfileComponent} from './user.profile.component'
import {UserRoutingModule} from './user-routing.module'
import {UserLoginComponent} from './user.login.component'
import {FormsModule} from '@angular/forms'
import {ReactiveFormsModule} from '@angular/forms' 
@NgModule({
  declarations: [UserProfileComponent,
                 UserLoginComponent
                ],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,ReactiveFormsModule
    ],
  providers : [],
  exports: [
    UserProfileComponent
  ]
 })
export class UserModule { }
