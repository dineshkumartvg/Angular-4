export interface IUser {
    userName : string
    password : string
    firstName : string
    lastName : string
}